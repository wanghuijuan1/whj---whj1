from distutils.core import setup
import py2exe
setup(console=["F:\\pyTestA\\TestScript\\targetEditorTool\\targetEditor.py"])