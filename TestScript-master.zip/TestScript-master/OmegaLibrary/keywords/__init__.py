from _omegaconsole import _OmegaConsoleKeywords
from _omegamp import _OmegaMpKeywords


__all__ = [
    "_OmegaConsoleKeywords",
    "_OmegaMpKeywords"
]
