VERSION = '0.5.7'

from faker.generator import Generator
from faker.factory import Factory

Faker = Factory.create
